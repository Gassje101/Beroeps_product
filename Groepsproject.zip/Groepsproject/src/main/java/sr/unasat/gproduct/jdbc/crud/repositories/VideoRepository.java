package sr.unasat.gproduct.jdbc.crud.repositories;


//Moet nog afgemaakt worden maar om het te laten werken heb ik em even out-gecomment
//ik heb alles wat met video te maken heeft out-gecomment


/*import sr.unasat.gproduct.jdbc.crud.entities.Video;
import sr.unasat.gproduct.jdbc.crud.entities.Editor;
import sr.unasat.gproduct.jdbc.crud.entities.Sponsor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

    public class VideoRepository {
        private Connection connection;
        public VideoRepository() {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("De driver is geregistreerd!");

                String URL = "jdbc:mysql://localhost/tv_studio";
                String USER = "root";
                String PASS = "Grpinyofacebam1";
                connection = DriverManager.getConnection(URL, USER, PASS);
                System.out.println(connection);
            } catch (ClassNotFoundException ex) {
                System.out.println("Error: unable to load driver class!");
                System.exit(1);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public List<Video> findAllRecords() {
            List<Video> videoList = new ArrayList<Video>();
            Statement stmt = null;
            try {
                stmt = connection.createStatement();
                String sql = "select v.video_id, v.datum, v.uitzending, v.length,  e.edit_id, s.sponsor_id from editor e + sponsor s" +
                        " join editor e, sponsor s" +
                        " on p.id = ci.persoon_id";
                ResultSet rs = stmt.executeQuery(sql);
                System.out.println("resultset: " + rs);
                //STEP 5: Extract data from result set
                while (rs.next()) {
                    //Retrieve by column name
                    int id = rs.getInt("id");
                    double datum = rs.getDouble("datum");

                    int edit_id = rs.getInt("edit_id");
                    int sponsor_id = rs.getInt("sponsor_id");

                    int persoonId = rs.getInt("pid");
                    String persoonNaam = rs.getString("pnaam");
                    Video video = new Video(persoonId, persoonNaam);

                    contactList.add(new ContactInformatie(id, adres, telefoonNummer, persoon));
                    //  persoonList.add(new Persoon(rs.getInt("id"), rs.getString("naam")));
                }
                rs.close();


            } catch (SQLException e) {

            } finally {

            }
            return contactList;
        }

        /*public ContactInformatie findOneRecord(int telNum, String ciAdres) {
            ContactInformatie contactInformatie = null;
            PreparedStatement stmt = null;
            try {
                String sql = "select ci.id, ci.adres, ci.telefoon_nummer , p.id pid, p.naam pnaam from contact_informatie ci" +
                        " join persoon p" +
                        " on p.id = ci.persoon_id where ci.telefoon_nummer = ? or ci.adres = ?";
                stmt = connection.prepareStatement(sql);
                stmt.setInt(1, telNum);
                stmt.setString(2, ciAdres);
                ResultSet rs = stmt.executeQuery();
                System.out.println("resultset: " + rs);
                //STEP 5: Extract data from result set
                if (rs.next()) {
                    //Retrieve by column name
                    int id = rs.getInt("id");
                    String adres = rs.getString("adres");
                    int telefoonNummer = rs.getInt("telefoon_nummer");

                    int persoonId = rs.getInt("pid");
                    String persoonNaam = rs.getString("pnaam");
                    Persoon persoon = new Persoon(persoonId, persoonNaam);

                    contactInformatie = new ContactInformatie(id, adres, telefoonNummer, persoon);
                }
                rs.close();


            } catch (SQLException e) {

            } finally {

            }
            return contactInformatie;
        }

        public int updateOneRecord(ContactInformatie contact) {
            PreparedStatement stmt = null;
            int result = 0;
            try {
                String sql = "update contact_informatie ci set ci.telefoon_nummer = ?, ci.persoon_id = ? where ci.id = ?";
                stmt = connection.prepareStatement(sql);
                stmt.setInt(1, contact.getTelefoonNummer());
                stmt.setInt(2, contact.getPersoon().getId());
                stmt.setInt(3, contact.getId());
                result = stmt.executeUpdate();
                System.out.println("resultset: " + result);

            } catch (SQLException e) {

            } finally {

            }
            return result;
        }

    }*/
