package sr.unasat.gproduct.jdbc.crud.entities;

//moet nog ingevuld worden met getter and setters en constructors

public class Video {
private int video_id;
private double datum;
private int edit_id;
private int sponsor_id;

}
