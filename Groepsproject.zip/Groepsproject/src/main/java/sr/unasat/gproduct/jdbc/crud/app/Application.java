package sr.unasat.gproduct.jdbc.crud.app;

import sr.unasat.gproduct.jdbc.crud.entities.Editor;
import sr.unasat.gproduct.jdbc.crud.entities.Sponsor;
import sr.unasat.gproduct.jdbc.crud.entities.Video;
import sr.unasat.gproduct.jdbc.crud.repositories.EditorRepository;
import sr.unasat.gproduct.jdbc.crud.repositories.SponsorRepository;
/*import sr.unasat.gproduct.jdbc.crud.repositories.VideoRepository;*/

import java.util.List;

        public class Application {

            public static void main(String[] args) {
                EditorRepository editorRepo = new EditorRepository();
                List<Editor> editorList = editorRepo.findAllRecords();
                for (Editor editor : editorList) {
                    System.out.println(editor);
                }

                SponsorRepository sponsorRepo = new SponsorRepository();
                List<Sponsor> sponsorList = sponsorRepo.findAllRecords();
                for (Sponsor sponsor : sponsorList) {
                    System.out.println(sponsor);
                }

                /*VideoRepository videoRepo = new VideoRepository();
                List<Video> videoList = videoRepo.findAllRecords();
                for (Video video : videoList) {
                    System.out.println(video);
                }*/



            }


        }

