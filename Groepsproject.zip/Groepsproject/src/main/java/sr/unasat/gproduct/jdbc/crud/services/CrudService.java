package sr.unasat.gproduct.jdbc.crud.services;

public class CrudService {
}
