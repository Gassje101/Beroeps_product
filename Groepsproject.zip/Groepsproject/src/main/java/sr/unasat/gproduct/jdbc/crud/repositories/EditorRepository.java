package sr.unasat.gproduct.jdbc.crud.repositories;


import com.mysql.jdbc.Driver;
import sr.unasat.gproduct.jdbc.crud.entities.Editor;
import sr.unasat.gproduct.jdbc.crud.entities.Sponsor;
import sr.unasat.gproduct.jdbc.crud.entities.Video;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

    public class EditorRepository {
        private Connection connection;

        public EditorRepository() {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("De driver is geregistreerd!");

                String URL = "jdbc:mysql://localhost/tv_studio";
                String USER = "root";
                String PASS = "Grpinyofacebam1";//je eigen password zetten van je driver
                connection = DriverManager.getConnection(URL, USER, PASS);
                System.out.println(connection);
            } catch (ClassNotFoundException ex) {
                System.out.println("Error: unable to load driver class!");
                System.exit(1);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public List<Editor> findAllRecords() {
            List<Editor> editorList = new ArrayList<Editor>();
            Statement stmt = null;
            try {
                stmt = connection.createStatement();
                String sql = "select * from editor";
                ResultSet rs = stmt.executeQuery(sql);
                System.out.println("resultset: " + rs);
                //STEP 5: Extract data from result set
                while (rs.next()) {
                    //Retrieve by column name
                    int id = rs.getInt("editor_id");
                    String naam = rs.getString("naam");
                    String voornaam = rs.getString("voornaam");
                //Display values
               System.out.print("ID: " + id);
               System.out.print(", NAME: " + naam);
               System.out.println(", FIRST NAME: " + voornaam);
                    /*editorList.add(new Editor(id, naam, voornaam));*/
                    //  editorList.add(new Editor(rs.getInt("id"), rs.getString("naam")));
                }
                rs.close();


            } catch (SQLException e) {

            } finally {

            }
            return editorList;
        }

        public int insertOneRecord(Editor editor) {
            PreparedStatement stmt = null;
            int result = 0;
            try {
                String sql = "insert into editor (naam) values(?)";
                stmt = connection.prepareStatement(sql);
                stmt.setString(1, editor.getNaam());
                result = stmt.executeUpdate();
                System.out.println("resultset: " + result);

            } catch (SQLException e) {

            } finally {

            }
            return result;
        }

        public int deleteOneRecord(Editor editor){
            PreparedStatement stmt = null;
            int result = 0;
            try {
                String sql = "DELETE FROM editor WHERE editor.id = ?";
                stmt = connection.prepareStatement(sql);
                stmt.setInt(1, editor.getId());
                result = stmt.executeUpdate();
                System.out.println("deleted: " + editor.getId());

            } catch (SQLException e) {

            } finally {

            }
            return result;
        }

    }
